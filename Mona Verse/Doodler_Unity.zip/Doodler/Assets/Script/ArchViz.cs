using UnityEngine;

public class ArchViz : MonoBehaviour
{
    public int currentModelIndex = 0;
    public bool isArchVizEnabled = false;
    public GameObject cursorArchViz;
    public GameObject floor;
    private LineDrawer lineDrawer;

    // Define the layer mask for interactable objects
    public LayerMask interactableLayer;

    void Update()
    {
        // Enable or disable the cursor based on isArchVizEnabled
        cursorArchViz.SetActive(isArchVizEnabled);

        if (isArchVizEnabled)
        {
            // Raycast from the camera to the mouse position
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            // Perform the raycast
            if (Physics.Raycast(ray, out hit))
            {
                // Update the position of the cursor to follow the mouse in the X-Z plane
                // The cursor will be positioned at the hit point on the ground
                Vector3 cursorPosition = hit.point;
                cursorPosition.y = cursorArchViz.transform.position.y; // Maintain the original Y position of the cursor
                cursorArchViz.transform.position = cursorPosition;

                // Check if the left mouse button is clicked
                if (Input.GetMouseButtonDown(0))
                {
                    // Check if the ray hits any collider in the specified layer
                    if (Physics.Raycast(ray, out hit, Mathf.Infinity, interactableLayer))
                    {
                        // Enable the MeshRenderer of the hit object
                        MeshRenderer meshRenderer = hit.collider.gameObject.GetComponent<MeshRenderer>();
                        if (meshRenderer != null)
                        {
                            meshRenderer.enabled = true;
                        }
                    }
                }

                // Check if the middle mouse button is clicked
                if (Input.GetMouseButtonDown(2))
                {
                    // Loop through all objects in the specified layer and disable their MeshRenderer components
                    GameObject[] objects = FindObjectsOfType<GameObject>();
                    foreach (GameObject obj in objects)
                    {
                        if (obj.layer == Mathf.Log(interactableLayer.value, 2)) // Check if object is in the specified layer
                        {
                            MeshRenderer meshRenderer = obj.GetComponent<MeshRenderer>();
                            if (meshRenderer != null)
                            {
                                meshRenderer.enabled = false;
                            }
                        }
                    }
                }
            }
            // Check for key press (1 or Numpad 1) to toggle the floor
            if (Input.GetKeyDown(KeyCode.Alpha1) || Input.GetKeyDown(KeyCode.Keypad1))
            {
                ToggleMeshRenderer(floor);
            }
        }
    }

    // To Toggle Mesh Renderer of any GameObject
    void ToggleMeshRenderer(GameObject obj)
    {
        lineDrawer = FindAnyObjectByType<LineDrawer>();
        Ray ray = lineDrawer.mainCamera.ScreenPointToRay(Input.mousePosition);
        lineDrawer.EraseLines(ray);

        // Enable MeshRenderer of the parent object if it exists
        MeshRenderer meshRenderer = obj.GetComponent<MeshRenderer>();
        if (meshRenderer != null)
        {
            meshRenderer.enabled = true;
        }

        // Iterate through all children and enable their MeshRenderer if it exists
        foreach (Transform child in obj.transform)
        {
            meshRenderer = child.gameObject.GetComponent<MeshRenderer>();
            if (meshRenderer != null)
            {
                meshRenderer.enabled = true;
            }
        }
    }

}
