using UnityEngine;

public class GameManager : MonoBehaviour
{
    /*void Start()
    {
        // Hide the cursor
        Cursor.visible = false;

        // Lock the cursor to the center of the game window
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        // Optional: Allow the player to unlock and show the cursor, e.g., by pressing Escape
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Cursor.visible = true;
            Cursor.lockState = CursorLockMode.None;
        }
    }*/
}
