using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using static UnityEngine.Rendering.DebugUI;

public class UIManager : MonoBehaviour
{
    public GameObject[] appPanel;
    public Slider brushSizeSlider;
    public FlexibleColorPicker colorPicker;
    public GameObject searchBar;
    public RectTransform appBarRectT;
    private LineDrawer lineDrawer;
    private ArchViz archViz;
    bool isColor2Check = false;

    private Vector3 panelOriginalPos, panelOriginalScale;
    public Toggle lineColorToggle;
    private void Start()
    {
        lineDrawer = FindObjectOfType<LineDrawer>();
        archViz = FindObjectOfType <ArchViz>();

        // Initialize Default values
        brushSizeSlider.value = lineDrawer.lineWidth;
        colorPicker.color = lineDrawer.lineStartColor;
    }

    public void EnableDoodleMenu(bool enable)
    {
        lineDrawer.isLineDrawerEnabled = enable;
    }
    public void EnableArchVizMenu(bool enable)
    {
        archViz.isArchVizEnabled = enable;
    }

    public void SetSlider()
    {
        lineDrawer.lineWidth = brushSizeSlider.value;
    }

    public void SetColor()
    {
        if (!isColor2Check)
        {
            lineDrawer.lineStartColor = colorPicker.color;
        }
        else
        {
            lineDrawer.lineEndColor = colorPicker.color;
        }
        
    }
    // For Color 2 Checkmark
    public void switchLineColor()
    {
        
        if (lineColorToggle.isOn)
        {
            isColor2Check = true;
            colorPicker.color = lineDrawer.lineEndColor;
        }
        else
        {
            isColor2Check = false;
            colorPicker.color = lineDrawer.lineStartColor;
        }
    }

    public void ShowAppPanel(GameObject showPanel)
    {
        foreach (GameObject panel in appPanel)
        {
            panel.SetActive(false);
        }
        EnableDoodleMenu(false);
        EnableArchVizMenu(false);
        showPanel.SetActive(true);

        // Setting Initial Values for Animations
        panelOriginalPos = showPanel.transform.position;
        panelOriginalScale = showPanel.transform.localScale;

        AnimatePanel(showPanel, false);

    }
    public void HideAppPanel(GameObject hidePanel)
    {
        AnimatePanel(hidePanel, true);  // Play exit animation then setActive to false
        EnableDoodleMenu(false);
        EnableArchVizMenu(false);
    }

    public void SetDoodlerTool(int setTool)
    {
        lineDrawer.currentTool = setTool;
    }

    // Animations
    private Vector3 searchBarScale, appBarRectTrans, appBarRectTrans2;
    private float growDuration = 0.5f;
    private float exitDuration = 0.5f;
    public void AnimateSearchBar(bool isExitAnimation)
    {
        if (!isExitAnimation)
        {
            searchBarScale  = searchBar.transform.localScale;
            appBarRectTrans = appBarRectT.sizeDelta;

            appBarRectTrans2 = appBarRectTrans;
            appBarRectTrans2.x *= 1.2f;

            // Grow animation
            LeanTween.size(appBarRectT, appBarRectTrans2, growDuration)
                .setEase(LeanTweenType.easeOutBack); // App Bar only horizontal
            LeanTween.scale(searchBar, searchBarScale * 1.4f, growDuration)
                .setEase(LeanTweenType.easeOutBack); // Search Bar

            // You can also set other properties like position, rotation, etc., as needed.
        }
        else
        {
            // Exit animation
            LeanTween.size(appBarRectT, appBarRectTrans, exitDuration)
                .setEase(LeanTweenType.easeInBack); // App Bar
            LeanTween.scale(searchBar, searchBarScale, exitDuration)
                .setEase(LeanTweenType.easeInBack); // Search Bar
        }
    }


    private Vector3 panelStartPos, panelStartScale;
    private RectTransform panelRect, panelRect2;
    public void AnimatePanel(GameObject panelGB, bool isExitAnimation)
    {
        if (!isExitAnimation)
        {
            // Setting Initial Positions
            panelStartPos = panelOriginalPos; panelStartPos.y -= 50f;
            panelStartScale = panelOriginalScale * 0.75f;

            // Keeping Panel at Start Values
            panelGB.transform.position = panelStartPos; 
            panelGB.transform.localScale = panelStartScale;

            // Animate Scale & Movement
            LeanTween.moveY(panelGB, panelGB.transform.position.y + 50f, growDuration)
                .setEase(LeanTweenType.easeInBack);
            LeanTween.scale(panelGB, panelOriginalScale, growDuration)
                .setEase(LeanTweenType.easeOutBack);
        }
        else
        {
            // Animate Scale & Movement for Exit
            LeanTween.moveY(panelGB, panelGB.transform.position.y - 50f, exitDuration)
                .setEase(LeanTweenType.easeOutBack);
                
            LeanTween.scale(panelGB, panelStartScale, exitDuration)
                .setEase(LeanTweenType.easeInBack)
                .setOnComplete(() => {
                     panelGB.SetActive(false);
                 });
        }
    }


}
