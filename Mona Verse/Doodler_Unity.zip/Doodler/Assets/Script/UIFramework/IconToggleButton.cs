using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class IconToggleButton : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public Sprite normal1, hover1, normal2, hover2;
    private Image btnIcon;
    [HideInInspector] public Button btn;
    public bool toggle = false;

    private void Awake()
    {
        btn = GetComponent<Button>();

        Transform imageChild = transform.Find("Image");
        if (imageChild != null)
        {
            btnIcon = imageChild.GetComponent<Image>();
        }
    }

    public void changeToIcon(int iconVal)
    {
        if (iconVal % 2 == 0)   { toggle = false; }
        if (iconVal % 2 != 0)    { toggle = true; }
    }

    public void toggleIcon()
    {
        if (!toggle) { toggle = true; }
        if (toggle) { toggle = false; }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (!toggle)
        {
            btnIcon.sprite = hover1;
        }

        if (toggle)
        {
            btnIcon.sprite = hover2;
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (!toggle)
        {
            btnIcon.sprite = normal1;
        }

        if (toggle)
        {
            btnIcon.sprite = normal2;
        }
    }
}
