using UnityEngine;
using UnityEngine.XR.ARFoundation;
using System.Collections.Generic;
public class PlacePrefabOnPlane : MonoBehaviour
{
    public GameObject prefabToPlace;
    private ARRaycastManager arRaycastManager;
    private List<ARRaycastHit> arRaycastHits = new List<ARRaycastHit>();

    void Start()
    {
        arRaycastManager = GetComponent<ARRaycastManager>();
    }

    void Update()
    {
        if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
        {
            Vector2 touchPosition = Input.GetTouch(0).position;
            if (arRaycastManager.Raycast(touchPosition, arRaycastHits, UnityEngine.XR.ARSubsystems.TrackableType.PlaneWithinPolygon))
            {
                Pose hitPose = arRaycastHits[0].pose;
                Instantiate(prefabToPlace, hitPose.position, hitPose.rotation);
            }
        }
    }
}
