using UnityEngine;

public class RotatingFloatingObject : MonoBehaviour
{
    public float rotationSpeed = 30f;   // Rotation speed in degrees per second
    //public float floatHeight = 1f;      // Height of the float motion
    //public float floatSpeed = 1f;       // Speed of the float motion

    private Vector3 initialPosition;

    void Start()
    {
        //initialPosition = transform.position;
    }

    void Update()
    {
        // Rotate the object around its up axis
        transform.Rotate(Vector3.up * rotationSpeed * Time.deltaTime);

        // Calculate the float motion using a sine wave
        //float floatOffset = Mathf.Sin(Time.time * floatSpeed) * floatHeight;
        //Vector3 newPosition = initialPosition + Vector3.up * floatOffset;

        // Update the object's position
        //transform.position = newPosition;
    }
}
