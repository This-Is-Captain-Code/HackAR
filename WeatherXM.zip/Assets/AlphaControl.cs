using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AlphaControl : MonoBehaviour
{
    public RawImage cameraRawImage;
    public Slider alphaSlider;

    void Start()
    {
        // Add a listener to the slider to respond to value changes
        alphaSlider.onValueChanged.AddListener(ChangeAlpha);
    }

    void ChangeAlpha(float alphaValue)
    {
        Color rawImageColor = cameraRawImage.color;
        rawImageColor.a = alphaValue;
        cameraRawImage.color = rawImageColor;
    }
}
