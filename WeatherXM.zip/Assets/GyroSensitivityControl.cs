using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GyroSensitivityControl : MonoBehaviour
{
    public CameraMovement cameraMovement; // Reference to the CameraMovement script
    public Slider sensitivitySlider;

    void Start()
    {
        // Add a listener to the slider to respond to value changes
        sensitivitySlider.onValueChanged.AddListener(ChangeSensitivity);
    }

    void ChangeSensitivity(float sensitivityValue)
    {
        cameraMovement.SetGyroSensitivity(sensitivityValue);
    }
}
