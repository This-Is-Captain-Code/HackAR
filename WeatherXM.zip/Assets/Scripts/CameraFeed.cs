using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CameraFeed : MonoBehaviour
{
    private WebCamTexture camTexture;

    void Start()
    {
        // Find the available webcams
        WebCamDevice[] devices = WebCamTexture.devices;

        if (devices.Length == 0)
        {
            Debug.LogError("No cameras found on the device.");
            return;
        }

        // Use the first available webcam
        camTexture = new WebCamTexture(devices[0].name, Screen.width, Screen.height);
        camTexture.Play();

        // Display the camera feed on the Raw Image component
        RawImage rawImage = GetComponent<RawImage>();
        rawImage.texture = camTexture;
    }
}
