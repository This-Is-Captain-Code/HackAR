using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraToSkybox : MonoBehaviour
{
    public Material skyboxMaterial;
    public Camera phoneCamera;

    void Start()
    {
        if (phoneCamera == null || skyboxMaterial == null)
        {
            Debug.LogError("Phone camera or skybox material not assigned.");
            return;
        }

        // Find the active camera in the scene if phoneCamera is not assigned
        if (phoneCamera == null)
        {
            Camera[] cameras = Camera.allCameras; // Get all cameras in the scene
            foreach (Camera cam in cameras)
            {
                if (cam.CompareTag("PhoneCamera")) // You can tag the phone camera with "PhoneCamera"
                {
                    phoneCamera = cam;
                    break;
                }
            }

            if (phoneCamera == null)
            {
                Debug.LogError("No phone camera found. Please assign the phone camera or tag it with 'PhoneCamera'.");
                return;
            }
        }

        RenderTexture renderTexture = new RenderTexture(Screen.width, Screen.height, 24);
        phoneCamera.targetTexture = renderTexture;
        skyboxMaterial.SetTexture("_Tex", renderTexture); // "_Tex" is the property name for the cubemap in the shader

        RenderSettings.skybox = skyboxMaterial;
    }
}
