using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    private bool gyroEnabled;
    private Gyroscope gyro;
    private GameObject cameraContainer;
    private Quaternion rot;
    private float gyroSensitivity = 2.5f; // Default sensitivity value

    void Start()
    {
        cameraContainer = new GameObject("Camera Container");
        cameraContainer.transform.position = transform.position;
        transform.SetParent(cameraContainer.transform);

        gyroEnabled = EnableGyro();

        if (!gyroEnabled)
        {
            Debug.LogError("Gyroscope not supported on this device.");
        }
    }

    bool EnableGyro()
    {
        if (SystemInfo.supportsGyroscope)
        {
            gyro = Input.gyro;
            gyro.enabled = true;
            cameraContainer.transform.rotation = Quaternion.Euler(90f, 90f, 0f);
            rot = new Quaternion(0, 0, 1, 0);
            return true;
        }
        return false;
    }

    public void SetGyroSensitivity(float sensitivity)
    {
        gyroSensitivity = sensitivity;
    }

    void Update()
    {
        if (gyroEnabled)
        {
            // Smooth the gyroscope rotation using Lerp
            Quaternion newRotation = gyro.attitude * rot;
            transform.localRotation = Quaternion.Slerp(transform.localRotation, newRotation, gyroSensitivity * Time.deltaTime);
        }
    }
}
