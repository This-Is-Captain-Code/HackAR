using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class IconButton : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public Sprite normal;
    public Sprite hover;
    private Image btnIcon;
    [HideInInspector] public Button btn;

    private void Awake()
    {
        btn = GetComponent<Button>();

        Transform imageChild = transform.Find("Image");
        if (imageChild != null)
        {
            btnIcon = imageChild.GetComponent<Image>();
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        btnIcon.sprite = hover;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        btnIcon.sprite = normal;
    }
}
