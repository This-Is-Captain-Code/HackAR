using UnityEngine;

public class LineDrawer : MonoBehaviour
{
    public Camera mainCamera;
    public GameObject linePrefab;
    public float maxDrawDistance = 100f;
    public int currentTool = 0; // 0 for line, 1 for eraser

    private GameObject currentLine;
    private LineRenderer lineRenderer;
    private Vector3 startPosition;
    private bool isDrawing = false;
    public bool isLineDrawerEnabled = false;

    public float eraseThreshold = 100f; // Adjust the value as needed

    public float lineWidth = 0.1f; // Default line width
    public Color lineStartColor = Color.yellow; // Default line color
    public Color lineEndColor = Color.red; // Default line color
    public GameObject floor;


    void Update()
    {
        if (isLineDrawerEnabled)
        {
            Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);

            if (currentTool == 0) // Line tool
            {
                if (Input.GetMouseButtonDown(0))
                {
                    if (!isDrawing)
                    {
                        StartDrawing(ray);
                    }
                    else
                    {
                        FinishDrawing(ray);
                    }
                }

                if (isDrawing)
                {
                    UpdateLine(ray);
                }
            }
            else if (currentTool == 1) // Eraser tool
            {
                if (Input.GetMouseButton(0))
                {
                    EraseLines(ray);
                }
            }

            // Check for middle mouse button click to cancel drawing and delete the line
            if (Input.GetMouseButtonDown(2))
            {
                if (isDrawing)
                {
                    CancelDrawing();
                }
            }
            // Check for key press (1 or Numpad 1) to toggle the floor
            if (Input.GetKeyDown(KeyCode.Alpha1) || Input.GetKeyDown(KeyCode.Keypad1))
            {
                ToggleMeshRenderer(floor);
            }
        }
    }

    void StartDrawing(Ray ray)
    {
        if (Physics.Raycast(ray, out RaycastHit hit, maxDrawDistance))
        {
            startPosition = hit.point;
        }
        else
        {
            startPosition = ray.GetPoint(maxDrawDistance);
        }

        CreateLine();
        isDrawing = true;
    }

    void FinishDrawing(Ray ray)
    {
        Vector3 endpoint;
        if (Physics.Raycast(ray, out RaycastHit hit, maxDrawDistance))
        {
            endpoint = hit.point;
        }
        else
        {
            endpoint = ray.GetPoint(maxDrawDistance);
        }

        if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
        {
            endpoint = SnapTo90DegreeAngles(startPosition, endpoint);
        }

        lineRenderer.SetPosition(1, endpoint);
        isDrawing = false;
    }


    void CreateLine()
    {
        currentLine = Instantiate(linePrefab);
        lineRenderer = currentLine.GetComponent<LineRenderer>();
        lineRenderer.startWidth = lineWidth;
        lineRenderer.endWidth = lineWidth;
        lineRenderer.startColor = lineStartColor;
        lineRenderer.endColor = lineEndColor;
        lineRenderer.SetPosition(0, startPosition);
        lineRenderer.SetPosition(1, startPosition);
    }

    void UpdateLine(Ray ray)
    {
        Vector3 endpoint;
        if (Physics.Raycast(ray, out RaycastHit hit, maxDrawDistance))
        {
            endpoint = hit.point;
        }
        else
        {
            endpoint = ray.GetPoint(maxDrawDistance);
        }

        if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
        {
            endpoint = SnapTo90DegreeAngles(startPosition, endpoint);
        }

        lineRenderer.SetPosition(1, endpoint);
    }
    // To snap lines at 90 degree
    Vector3 SnapTo90DegreeAngles(Vector3 start, Vector3 end)
    {
        Vector3 direction = end - start;
        Vector3 snapDirection = new Vector3(
            Mathf.Round(direction.x),
            Mathf.Round(direction.y),
            Mathf.Round(direction.z)
        ).normalized;

        float maxDistance = Mathf.Max(Mathf.Abs(direction.x), Mathf.Abs(direction.y), Mathf.Abs(direction.z));
        return start + snapDirection * maxDistance;
    }

    void CancelDrawing()
    {
        Destroy(currentLine);
        isDrawing = false;
    }

    // Function to erase lines when using the eraser tool
    public void EraseLines(Ray ray)
    {
        Vector3 rayPosition = ray.origin;
        Vector3 rayDirection = ray.direction;

        // Loop through all the lines that were drawn
        foreach (GameObject drawnLine in GameObject.FindGameObjectsWithTag("DrawnLine"))
        {
            LineRenderer lineRenderer = drawnLine.GetComponent<LineRenderer>();

            // Loop through each segment of the line
            for (int i = 0; i < lineRenderer.positionCount - 1; i++)
            {
                Vector3 segmentStart = lineRenderer.GetPosition(i);
                Vector3 segmentEnd = lineRenderer.GetPosition(i + 1);

                // Calculate the closest point on the line segment to the cursor
                Vector3 closestPoint = GetClosestPointOnSegment(rayPosition, rayDirection, segmentStart, segmentEnd);

                // Check if the distance between the closest point and the cursor is below a certain threshold
                float distance = Vector3.Distance(rayPosition, closestPoint);
                if (distance < eraseThreshold)
                {
                    // Erase the line by destroying the game object
                    Destroy(drawnLine);
                    break; // No need to check further segments of this line
                }
            }
        }
    }

    // Function to find the closest point on a line segment to a given point
    Vector3 GetClosestPointOnSegment(Vector3 point, Vector3 direction, Vector3 segmentStart, Vector3 segmentEnd)
    {
        Vector3 segmentDirection = segmentEnd - segmentStart;
        float t = Vector3.Dot(point - segmentStart, segmentDirection) / Vector3.Dot(segmentDirection, segmentDirection);

        // Clamp t to ensure the closest point is within the segment
        t = Mathf.Clamp01(t);

        Vector3 closestPoint = segmentStart + t * segmentDirection;
        return closestPoint;
    }

    // Arch Viz
    // To Toggle Mesh Renderer of any GameObject
    void ToggleMeshRenderer(GameObject obj)
    {
        // First erase Line Renderer lines
        Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
        EraseLines(ray);

        // Enable MeshRenderer of the parent object if it exists
        MeshRenderer meshRenderer = obj.GetComponent<MeshRenderer>();
        if (meshRenderer != null)
        {
            meshRenderer.enabled = true;
        }

        // Iterate through all children and enable their MeshRenderer if it exists
        foreach (Transform child in obj.transform)
        {
            meshRenderer = child.gameObject.GetComponent<MeshRenderer>();
            if (meshRenderer != null)
            {
                meshRenderer.enabled = true;
            }
        }
    }


}
