using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIItems : MonoBehaviour
{
    public List<Button> buttons; // Assign your buttons here in the inspector

    void Start()
    {
        // Add click listeners to buttons
        foreach (Button btn in buttons)
        {
            btn.onClick.AddListener(() => ItemSelectButtonClicked(btn));
        }
    }

    void ItemSelectButtonClicked(Button clickedButton)
    {
        // Enable the frame of the clicked button and disable others
        foreach (Button btn in buttons)
        {
            GameObject frame = btn.transform.Find("Frame").gameObject; // Assuming the frame is a direct child
            frame.SetActive(btn == clickedButton);
        }
    }
}
