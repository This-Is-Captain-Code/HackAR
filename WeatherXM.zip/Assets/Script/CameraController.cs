using UnityEngine;
using TMPro; // Add this namespace to use TextMeshPro

public class CameraController : MonoBehaviour
{
    public float speed = 2.0f;
    public float sensitivity = 2.0f;
    public float fastMultiplier = 4.0f;
    public float slowMultiplier = 0.25f;
    public float scrollSensitivity = 1.0f;
    public TextMeshProUGUI speedDisplayText; // TextMesh Pro UI element

    private float yaw = 0.0f;
    private float pitch = 0.0f;

    void Update()
    {
        // Check if the right mouse button is held down
        if (Input.GetMouseButtonDown(1))
        {
            // Hide cursor
            Cursor.visible = false;
            Cursor.lockState = CursorLockMode.Locked;
        }

        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll != 0)
        {
            speed += scroll * scrollSensitivity;
            speed = Mathf.Max(0.1f, speed);
        }

        float currentSpeed = speed;
        string speedText = speed.ToString("F2") + "x"; // Display the current speed

        if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
        {
            currentSpeed *= fastMultiplier;
            speedText = (speed * fastMultiplier).ToString("F2") + "x";
        }
        else if (Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl))
        {
            currentSpeed *= slowMultiplier;
            speedText = (speed * slowMultiplier).ToString("F2") + "x";
        }

        // Always update the speed display text
        if (speedDisplayText != null && speedDisplayText.isActiveAndEnabled)
        {
            speedDisplayText.text = "Speed: " + speedText;
        }

        if (Input.GetMouseButton(1))
        {
            // Camera control code

            yaw += sensitivity * Input.GetAxis("Mouse X");
            pitch -= sensitivity * Input.GetAxis("Mouse Y");
            transform.eulerAngles = new Vector3(pitch, yaw, 0.0f);

            float x = Input.GetAxis("Horizontal");
            float z = Input.GetAxis("Vertical");

            Vector3 direction = transform.right * x + transform.forward * z;
            transform.position += direction * currentSpeed * Time.deltaTime;
        }

        // Check if the right mouse button is released
        if (Input.GetMouseButtonUp(1))
        {
            // Show cursor and unlock it
            Cursor.visible = true;
            Cursor.lockState = CursorLockMode.None;
        }
    }
}