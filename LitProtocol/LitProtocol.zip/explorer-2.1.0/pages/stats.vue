<template>
  <Stats/>
</template>
