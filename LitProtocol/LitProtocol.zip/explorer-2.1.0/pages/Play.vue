<template>
  <div class="login-page">
    <button @click="connectWallet" @animationend="animationEnded" :class="{'animate': isAnimating}">Push To Play</button>
    <div v-if="error" class="error">{{ error }}</div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { ethers } from 'ethers';
import { useRouter } from 'vue-router';

// List of allowed addresses
const allowedAddresses = [
  '0xa08D90aa50e8C8cC95443610F05EA2Bc081D04f6'.toLowerCase(),
  '0xa08D90aa50e8C8cC95443610F05EA2Bc081D04f6'.toLowerCase()
];

const error = ref('');
const isAnimating = ref(false);
const router = useRouter();

const connectWallet = async () => {
  try {
    // Trigger animation
    isAnimating.value = true;

    // Check if MetaMask is installed
    if (!(window as any).ethereum) {
      error.value = 'MetaMask is not installed. Please install it to use this app.';
      return;
    }

    // Request account access
    await (window as any).ethereum.request({ method: 'eth_requestAccounts' });

    const provider = new ethers.providers.Web3Provider((window as any).ethereum);
    const signer = provider.getSigner();
    const address = (await signer.getAddress()).toLowerCase(); // Lowercase the fetched address

    console.log('Connected address:', address);
    console.log('Allowed addresses:', allowedAddresses);

    // Check if the address is allowed
    if (allowedAddresses.includes(address)) {
      //router.push('/stats');
      error.value = 'Loading Please Wait';
    } else {
      error.value = `Access denied. Your address (${address}) is not allowed.`;
    }
  } catch (err) {
    error.value = 'An error occurred while connecting to MetaMask.';
    console.error(err);
  }
};

const animationEnded = () => {
  isAnimating.value = false;
};
</script>

<style scoped>
html, body {
  margin: 0;
  padding: 0;
  height: 100%;
  width: 100%;
}

#app {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  width: 100%;
}

.login-page {
  position: fixed;
  top: 0;
  left: 0;
  width: 440%; /* Changed to 100% from 450% */
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-image: url('D:\JENIL_CS_PROJECTS\Web3\LitLogin\explorer-2.1.0\assets\Blue-Img.jpg'); /* Add your image path here */
  background-size: cover; /* Cover the entire container */
  background-repeat: no-repeat; /* Prevent the image from repeating */
  background-position: center; /* Center the image */
}

h1 {
  margin-bottom: 20px;
  color: green;
  align-items: center;
}

button {
  padding: 10px 20px;
  font-size: 16px;
  cursor: pointer;
  color: white;
  background-color: #000000;
  border: none;
  border-radius: 5px;
  transition: background-color 0.3s, transform 0.3s;
  outline: none;
}

button:hover {
  background-color: #45a049;
}

button:active {
  transform: scale(0.95);
}

button.animate {
  animation: pulse 0.5s ease-out;
}

@keyframes pulse {
  0% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.1);
  }
  100% {
    transform: scale(1);
  }
}

.error {
  color: red;
  margin-top: 20px;
}
</style>
